<?php
// Download the Stripe PHP SDK from https://github.com/stripe/stripe-php and place all files here.
// For Composer: composer require stripe/stripe-php
?>