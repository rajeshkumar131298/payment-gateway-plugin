# Global Business Payment Gateway (WordPress Plugin)

## Features

- Stripe & PayPal integration (sandbox-ready, extend to live easily)
- AI-powered fraud detection (Stripe Radar demo, extendable to real APIs)
- Automatic PDF invoice generation (uses TCPDF)
- Donor/charity mode, recurring payments
- Custom fee rules, admin analytics & reporting

## Installation

1. **Copy Plugin Files:**  
   Place all plugin files (main PHP, assets, lib/tcpdf, lib/stripe) into a new folder named `payment-gateway-plugin` in your `wp-content/plugins/` directory.

2. **TCPDF Library:**  
   Download [TCPDF](https://tcpdf.org/) and put the library files inside `lib/tcpdf/` so that `tcpdf.php` and dependencies are present.

3. **Stripe PHP Library:**  
   Download from [GitHub](https://github.com/stripe/stripe-php) or install via Composer into `lib/stripe/`.

4. **Activate Plugin:**  
   Go to your WordPress dashboard, Plugins, and activate "Global Business Payment Gateway".

5. **Set API Keys:**  
   - Edit the plugin file to add your Stripe/PayPal live API keys as needed.
   - For production, replace the demo payment logic with real SDK/API integrations.

6. **Usage:**  
   Add `[gbpg_payment_form]` shortcode to any page or post to display the payment form.

## Customization

- **Payment Integration:**  
  Replace the demo logic in `process_payment()` with real Stripe/PayPal SDK/API code if desired.
- **AI Fraud Detection:**  
  Integrate Stripe Radar or any other fraud detection API using the provided hooks.
- **Invoice Generation:**  
  The plugin uses TCPDF for invoices. Customize the output in `generate_invoice_pdf()`.

## Security

- All user input is sanitized and processed using WordPress best practices.
- Nonce verification is enforced for AJAX.
- Always test in sandbox mode before deploying live.

## Support

For questions or feature requests, open an issue or contact the author.