jQuery(document).ready(function($){
    $('#gbpg-payment-form').on('submit', function(e){
        e.preventDefault();
        var form = $(this);
        var data = form.serialize() + '&nonce=' + gbpg_ajax.nonce;
        $.post(gbpg_ajax.ajax_url, data + '&action=gbpg_process_payment', function(response){
            if(response.success) {
                $('#gbpg-payment-result').html('<div class="success">' + response.data.message + '<br><a href="'+response.data.invoice+'" target="_blank">Download Invoice</a></div>');
            } else {
                $('#gbpg-payment-result').html('<div class="error">' + response.data.message + '</div>');
            }
        });
    });
});